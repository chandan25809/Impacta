ALTER TABLE supporttickets 
DROP COLUMN IF EXISTS query;

ALTER TABLE supporttickets 
DROP COLUMN IF EXISTS answer;
