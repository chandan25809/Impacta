ALTER TABLE campaigns DROP COLUMN category;
